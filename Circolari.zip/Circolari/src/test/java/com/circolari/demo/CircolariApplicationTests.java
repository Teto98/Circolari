package com.circolari.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CircolariApplicationTests {

	@Test
	void contextLoads() {
	}

}
